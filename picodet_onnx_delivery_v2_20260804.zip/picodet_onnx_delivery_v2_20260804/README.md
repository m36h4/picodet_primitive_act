# PicoDet ONNX — Client Delivery Package (v2 — updated)

**Version 2** — supersedes the previously shared package. See "What changed" below.

## What changed since the last delivery

- Re-exported and re-simplified both models to resolve the
  `[ONNXRuntimeError] Node (p2o.Gather.8) ... data tensor must have rank >= 1`
  error seen previously.
- Verified on two independent environments (CPU/Windows and GPU/Linux) with
  matching results — see "Verified environments" below.
- Pinned dependency versions in `requirements.txt` to prevent this from
  recurring due to an environment mismatch.

## Folder contents

```
picodet_onnx_delivery_v2_20260804/
├── README.md                      <- this file (setup + usage notes)
├── requirements.txt                <- pinned dependencies for inference
├── models/
│   ├── standard_picodet_sim.onnx   <- standard activations, opset 12
│   └── primitive_picodet_sim.onnx  <- custom hard-sigmoid/hard-swish, opset 13
└── scripts/
    ├── check_env_info.py           <- verifies env + prints model I/O info
    └── run_inference_test.py       <- minimal load + inference sanity check
```

## Which model to use

| File | Opset | Activations | When to use |
|---|---|---|---|
| `standard_picodet_sim.onnx` | 12 | standard sigmoid / swish | default |
| `primitive_picodet_sim.onnx` | 13 | hard-sigmoid / hard-swish | if target hardware doesn't support standard sigmoid/swish ops |

## Verified environments

Both models were tested and confirmed working in the environments below.
**Paddle / paddle2onnx / onnxsim are NOT required for inference** — they were
only used on our side to export and simplify the model.

| Platform | Python | onnxruntime | numpy |
|---|---|---|---|
| CPU (Windows) | 3.10 | 1.23.2 | 1.26.4 |
| GPU (Linux, SSH) | 3.10 | 1.23.2 | 1.26.4 |

Recommend pinning `onnxruntime==1.23.2` (or newer) on your end.

## Setup

```bash
python -m venv onnx_infer_env
source onnx_infer_env/bin/activate      # Windows: onnx_infer_env\Scripts\activate
pip install -r requirements.txt
```

## Verify the environment + inspect model info

```bash
python scripts/check_env_info.py models/standard_picodet_sim.onnx
python scripts/check_env_info.py models/primitive_picodet_sim.onnx
```

This prints the model's opset/IR version, your installed package versions,
and the model's input/output names, shapes, and types — confirm these match
the table above before integrating.

## Quick inference sanity check

```bash
python scripts/run_inference_test.py models/standard_picodet_sim.onnx
```

Loads the model and runs a single dummy forward pass to confirm there are no
load-time or shape errors. Replace the dummy input with a real preprocessed
image before relying on the output values.

## Model input/output reference

Inputs:
- `image` — shape `[N, 3, 320, 320]`, type float32
- `scale_factor` — shape `[1, 2]`, type float32

Outputs:
- `save_infer_model/scale_0.tmp_0` — shape `[N, 6]`, type float32 (boxes: class, score, x1, y1, x2, y2)
- `save_infer_model/scale_1.tmp_0` — shape `[1]`, type int32 (box count)

## Known issue history (for reference)

An earlier export failed with:
```
[ONNXRuntimeError] : 1 : FAIL : Node (p2o.Gather.8) Op (Gather)
[ShapeInferenceError] data tensor must have rank >= 1
```
This was resolved by running the exported model through `onnx-simplifier`
before delivery. The models in this package have already had this fix
applied — no action needed on your end for this specific issue.

## Contact

If `check_env_info.py` or `run_inference_test.py` fail on your setup, please
send back the full console output plus your `pip freeze` output so we can
compare against the verified environments above.
