"""
run_inference_test.py

Loads the ONNX model and runs a single dummy forward pass to confirm
there are no load-time or shape errors. This does NOT validate detection
accuracy — replace the dummy input with a real preprocessed image before
relying on the output values.

Usage:
    python run_inference_test.py path/to/model.onnx
"""

import sys
import numpy as np
import onnxruntime as ort


def main():
    if len(sys.argv) < 2:
        print("Usage: python run_inference_test.py path/to/model.onnx")
        sys.exit(1)

    model_path = sys.argv[1]

    print(f"Loading {model_path} ...")
    sess = ort.InferenceSession(model_path)
    print("Model loaded successfully.\n")

    inputs = sess.get_inputs()
    feed = {}
    for inp in inputs:
        shape = [d if isinstance(d, int) else 1 for d in inp.shape]
        # Force the standard PicoDet 320x320 input size when dims are dynamic
        if inp.name == "image":
            shape = [1, 3, 320, 320]
        elif inp.name == "scale_factor":
            shape = [1, 2]
            feed[inp.name] = np.array([[1.0, 1.0]], dtype=np.float32)
            continue
        feed[inp.name] = np.random.rand(*shape).astype(np.float32)

    print("Running dummy forward pass with input shapes:")
    for name, arr in feed.items():
        print(f"  - {name}: {arr.shape}")

    outputs = sess.run(None, feed)

    print("\nInference ran successfully. Output shapes:")
    for out_info, out_val in zip(sess.get_outputs(), outputs):
        print(f"  - {out_info.name}: {out_val.shape}")

    print("\nNo shape/runtime errors. Replace dummy input with a real")
    print("preprocessed image before trusting the output values.")


if __name__ == "__main__":
    main()
